Building an AngularJS Website Using Routes
======================

This is a simple AngularJS website using routes and partials. I have also included StateService to show how to preserve state across route changes.

